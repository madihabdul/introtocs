public class Accessories {

    public String key;
    public boolean potion = false;
    public boolean ring = false;
    public boolean shield = false;

    public Accessories() {
        // key
        if(key == true) {
            System.out.println("You have the key to defeat the wizard!");
        }
        // potion
        // ring
        // shield
    }
}
