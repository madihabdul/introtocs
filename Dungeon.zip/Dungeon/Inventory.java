public class Inventory {
    
}
