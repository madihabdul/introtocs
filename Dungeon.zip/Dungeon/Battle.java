public class Battle {

}
